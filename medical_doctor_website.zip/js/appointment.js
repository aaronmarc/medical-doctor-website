
document.getElementById('appointment-form').addEventListener('submit', function(event){
    event.preventDefault();
    const patientName = document.getElementById('patientName').value;
    const appointmentDate = document.getElementById('appointmentDate').value;
    const appointmentTime = document.getElementById('appointmentTime').value;

    console.log('Appointment Details:', patientName, appointmentDate, appointmentTime);

    alert('Appointment booked for ' + patientName + ' on ' + appointmentDate + ' at ' + appointmentTime);
});

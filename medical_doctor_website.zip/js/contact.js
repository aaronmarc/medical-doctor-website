
document.getElementById('contact-form').addEventListener('submit', function(event){
    event.preventDefault();
    const name = document.getElementById('contactName').value;
    const email = document.getElementById('contactEmail').value;
    const message = document.getElementById('contactMessage').value;

    console.log('Contact Details:', name, email, message);

    alert('Thank you for your message, ' + name + '. We will get back to you soon.');
});


document.getElementById('appointment-form').addEventListener('submit', function(event){
    event.preventDefault();
    /* Form handling logic */
});
